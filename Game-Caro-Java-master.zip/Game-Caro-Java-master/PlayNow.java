package GameCaro;

import java.awt.Color;
import java.awt.Label;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
//import org.omg.PortableInterceptor.USER_EXCEPTION;
public class PlayNow extends Thread {

    private JPanel user;

    public PlayNow(JPanel user) {
        this.user = user;
    }

    @Override
    public void run() {
        while (true) {
        	
            user.setBorder(new LineBorder(Color.RED));
            user.setBackground(new Color(238, 238, 238));
            user.add(new Label("Hello"));
//            user.setColor(Color.WHITE);
            try {
                Thread.sleep(1000);
                user.setBackground(new Color(220, 220, 220));
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
            }
        }
    }
}
