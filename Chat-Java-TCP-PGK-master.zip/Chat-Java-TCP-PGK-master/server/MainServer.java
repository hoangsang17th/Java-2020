
package server;

import server.MainServer.HandleClient.ProcessClient;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class MainServer extends javax.swing.JFrame {

    
    public MainServer() {
        initComponents();
        try 
        {
           s = new ServerSocket(2005);
           slist = new ArrayList<>();
           nlist = new ArrayList<>();
           h = new HandleClient();
           h.start();
        
           
        }catch(Exception e){}
    }

    
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        namelist = new javax.swing.JTable();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        txtcmd = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cid = new javax.swing.JTextField();
        jInternalFrame2 = new javax.swing.JInternalFrame();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtmsg = new javax.swing.JTextArea();
        mid = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        display = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Main Windows(SERVER)");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        namelist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Clients"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        namelist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                namelistMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(namelist);
        if (namelist.getColumnModel().getColumnCount() > 0) {
            namelist.getColumnModel().getColumn(0).setResizable(false);
        }

        jInternalFrame1.setTitle("Send Command To Client");
        jInternalFrame1.setVisible(true);

        jButton1.setText("Send Command");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Send Command To");

        cid.setEditable(false);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addComponent(txtcmd)
                        .addContainerGap())
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cid, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))))
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtcmd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(51, Short.MAX_VALUE))
        );

        jInternalFrame2.setTitle("Send Message To Client");
        jInternalFrame2.setVisible(true);

        txtmsg.setColumns(20);
        txtmsg.setRows(5);
        jScrollPane2.setViewportView(txtmsg);

        mid.setEditable(false);

        jButton3.setText("Send Message");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel2.setText("Send Message To");

        javax.swing.GroupLayout jInternalFrame2Layout = new javax.swing.GroupLayout(jInternalFrame2.getContentPane());
        jInternalFrame2.getContentPane().setLayout(jInternalFrame2Layout);
        jInternalFrame2Layout.setHorizontalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addGroup(jInternalFrame2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mid, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        jInternalFrame2Layout.setVerticalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addContainerGap(37, Short.MAX_VALUE))
        );

        display.setColumns(20);
        display.setRows(5);
        jScrollPane3.setViewportView(display);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jInternalFrame1)
                    .addComponent(jInternalFrame2)
                    .addComponent(jScrollPane3))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jInternalFrame2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try {
            s.close();
            System.exit(0);
        } catch (IOException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void namelistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_namelistMouseClicked
       String data = String.valueOf(((DefaultTableModel)namelist.getModel()).getValueAt(namelist.getSelectedRow(), 0));
        mid.setText(data.substring(data.indexOf("[")+1, data.indexOf("]")));
        cid.setText(data.substring(data.indexOf("[")+1, data.indexOf("]")));
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(!txtcmd.getText().equals("") && !cid.getText().equals(""))
        {
            Socket cl = slist.get(Integer.parseInt(cid.getText()));
            try
            {
              out = new PrintWriter(cl.getOutputStream(), true) ;
              out.println("cmd:"+txtcmd.getText());
            }catch(Exception e){}
        }
        txtcmd.setText("");
        cid.setText("");
        txtmsg.requestFocus();
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if(!txtmsg.getText().equals("") && !mid.getText().equals(""))
        {
            Socket cl = slist.get(Integer.parseInt(mid.getText()));
            try
            {
              out = new PrintWriter(cl.getOutputStream(), true) ;
              String contents =  txtmsg.getText();
              contents.replace("\n","~");
              //contents.replace("\r", "~");
              contents = contents + "\n"; 
              out.println("msg:"+txtmsg.getText());
            }catch(Exception e){}
        }
        txtmsg.setText("");
        mid.setText("");
        txtmsg.requestFocus();    
    }

    
  public  void loadList() 
  {
     while(namelist.getRowCount()>0)
     {
         ((DefaultTableModel)namelist.getModel()).removeRow(0);
     }
     int row = 0;
     for(int x=0;x<nlist.size();x++)
     {
       if(!nlist.get(x).equals(""))
       {
         ((DefaultTableModel)namelist.getModel()).addRow(new Object[]{}); 
         ((DefaultTableModel)namelist.getModel()).setValueAt(nlist.get(x), row, 0);
         row++;
       }
     }
  }
  private ServerSocket s;
  private Socket c;
  private String name; 
  private ArrayList<Socket> slist;
  private ArrayList<String> nlist;
  private BufferedReader brc;
  private PrintWriter out;
  private HandleClient h;
  
    
    private javax.swing.JTextField cid;
    private javax.swing.JTextArea display;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JInternalFrame jInternalFrame2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField mid;
    private javax.swing.JTable namelist;
    private javax.swing.JTextField txtcmd;
    private javax.swing.JTextArea txtmsg;
   
class HandleClient extends Thread  // TO HANDLE ALL CLIENTS
{ 
    private int tid;
    public void SendToAllClients(String message)
    {
        Socket so;
        PrintWriter out;
        for(int x=0;x<slist.size();x++)
        {
            try
            {
               so =  slist.get(x);
               out = new PrintWriter(so.getOutputStream(),true);
               out.println(message);
               
            }catch(Exception e){}
        }
    }
    class ProcessClient extends Thread
    {
      private int id;
      private String name;
      private Socket c;
      private BufferedReader brc; // TO READ FROM CLIENTS
      public ProcessClient(int id, String name, Socket c)
      {
          this.id = id;
          this.name = name;
          this.c = c;
      }
      public void run()
      {
          String msg;
          try{
          brc = new BufferedReader(new InputStreamReader(c.getInputStream()));
         loadList();
          SendToAllClients(name + " Joined Us");
          while((msg = brc.readLine())!= null)
          {
              display.append("["+name+"] : "+msg+"\n");
              SendToAllClients("["+name+"] : "+msg);
          }
          SendToAllClients(name+ "Left Us");
          nlist.set(id,"");
         loadList();
         }catch(Exception  e){}
      }
      
    }
    public void run()
    {
       while(true)
       {
           try {
               
               c = s.accept();
               brc =  new BufferedReader(new InputStreamReader(c.getInputStream()));
               name = brc.readLine();
               slist.add(c);
               nlist.add(name+ "["+tid+"]");
               ProcessClient t = new ProcessClient(tid ,name, c);
               t.start();
               tid++;
           } catch (IOException ex) {
               Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
    }
}
        
}

