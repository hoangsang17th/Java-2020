
package server;


public class Server {
    public static void main(String[] args) {
        MainServer m = new MainServer();
        m.setVisible(true);        
    }
    
}
