package CuoiKy;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.Socket;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class OutputThread extends Thread{
	private  DefaultListModel mod= new DefaultListModel();
	Socket socket;
	JTextArea txt;
	ObjectInputStream in;
	String sender;
	String receiver;
	JList list;
	public OutputThread(Socket socket, JTextArea txt, String sender, String receiver, JList list) {
		super();
		this.list = list;
		this.socket = socket;
		this.txt = txt;
		
		this.sender = sender;
		this.receiver = receiver;
		try {
			in = new ObjectInputStream(socket.getInputStream());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Network rerror");
			
		}
	}

	@Override
	public void run() {
		while (true) {
			
			try {
				if(socket != null) {
					list.setModel(mod);
					String message = "";
					Data2 data = (Data2) in.readObject();
					String stt = data.getStt();
					if (stt.equals("mess")) {
						txt.append(String.format("\n%s: %s", receiver, data.getMess()));
					}
					else if (stt.equals("Img") || stt.equals("File")){
						txt.append("\nDa nhan 1 file");
						mod.addElement(data);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
