package CuoiKy;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;

public class ManagerChatter extends JFrame implements Runnable{

	private JPanel contentPane;
	private JTabbedPane jTabbedPane1;
	private JLabel lblManagerPort;
	private JTextField txtServerPort;
	ServerSocket serverSocket = null;
	ObjectInputStream in;
	Thread thread;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerChatter frame = new ManagerChatter();
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public void run() {
		
		while(true) {
			try {
				Socket staffSocket = serverSocket.accept();
				if(staffSocket != null) {
					in = new ObjectInputStream(staffSocket.getInputStream());
					Data2 data = new Data2();
					String staffName = data.getName();
					ChatPanel chatPanel = new ChatPanel(staffSocket, "Manager", staffName);
					System.out.println(staffName);
					
					jTabbedPane1.add(staffName, chatPanel);
					chatPanel.updateUI();
					Thread.sleep(1000); //refresh check connect from client after 1 second
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public ManagerChatter() {
		setTitle("Server");
		initComponents();
	
		int serverPort = Integer.parseInt(txtServerPort.getText().trim());
		try {
			serverSocket = new ServerSocket(serverPort);
			this.lblManagerPort.setText("Server is running at Port: ");
		} catch (Exception e) {
			e.printStackTrace();
		}
		thread = new Thread(this);
		thread.start();
	}
	
	private void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 200, 951, 564);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel jPanel1 = new JPanel();
		contentPane.add(jPanel1, BorderLayout.NORTH);
		jPanel1.setLayout(new GridLayout(0, 2, 0, 0));
		
		lblManagerPort = new JLabel("Manager Port:");
		jPanel1.add(lblManagerPort);
		
		txtServerPort = new JTextField();
		txtServerPort.setText("2211");
		jPanel1.add(txtServerPort);
		txtServerPort.setColumns(10);
		
		jTabbedPane1 = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(jTabbedPane1, BorderLayout.CENTER);
	}

}
