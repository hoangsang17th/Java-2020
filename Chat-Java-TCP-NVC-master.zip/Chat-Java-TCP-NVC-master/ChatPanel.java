package CuoiKy;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import javax.swing.JScrollPane;
import java.awt.GridBagConstraints;
import javax.swing.JTextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.border.TitledBorder;
import javax.xml.crypto.Data;

import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.Label;

import javax.swing.DropMode;
import java.awt.FlowLayout;
import java.awt.Frame;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import java.awt.Color;

public class ChatPanel extends JPanel {

	Socket socket = null;
	ObjectOutputStream out;
	OutputThread outPutThread = null;
	String sender, receiver;
	JTextArea txtMessages;
	JTextArea txtMessage;
	JComboBox comboBox;
	Data2 chon;
	private JList list;
	private DefaultListModel mod = new DefaultListModel();
	public ChatPanel(Socket s, String sender, String receiver) {
		initComponents();
		this.socket = s;
		this.sender = sender;
		this.receiver = receiver;
		
		try {
			list = new JList();
			list.setModel(mod);
		
			list.addMouseListener(new  MouseListener() {
				
				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					chon = (Data2) list.getSelectedValue();
				}
				
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
			});
			out = new ObjectOutputStream(s.getOutputStream());
			outPutThread = new OutputThread(socket, txtMessages, sender, receiver, list);
			
			JPanel panel = new JPanel();
			panel.setBackground(new Color(176, 224, 230));
			add(panel, BorderLayout.EAST);
			
			JButton btnSave = new JButton("Save");
			btnSave.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if (chon!= null) {
						JFileChooser ch = new JFileChooser();
						int c = ch.showSaveDialog(null);
						if (c == JFileChooser.APPROVE_OPTION) {
							FileOutputStream outFile;
							try {
								outFile = new FileOutputStream(ch.getSelectedFile());
								outFile.write(chon.getFile());
								outFile.close();
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
					}
				}
			});
			JButton btnOpen = new JButton("Open");
			btnOpen.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if (chon!= null) {
						JFrame frame =new JFrame();      
							frame.setVisible(true);
					
							ImageIcon anh = new ImageIcon(chon.getFile());
							int x = anh.getIconWidth();
							int y = anh.getIconHeight();
							frame.setSize(x, y);
							JLabel lb = new JLabel();
							lb.setIcon(anh);
							frame.setTitle(chon.getName());
							frame.getContentPane().add(lb);
							frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
					}
				
				}
			});
			
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon(ChatPanel.class.getResource("/CuoiKy/Untitled-3.jpg")));
			
			GroupLayout gl_panel = new GroupLayout(panel);
			gl_panel.setHorizontalGroup(
				gl_panel.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_panel.createSequentialGroup()
						.addContainerGap()
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_panel.createSequentialGroup()
								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
									.addComponent(list, GroupLayout.PREFERRED_SIZE, 174, GroupLayout.PREFERRED_SIZE)
									.addGroup(gl_panel.createSequentialGroup()
										.addComponent(btnSave, GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
										.addGap(18)
										.addComponent(btnOpen, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)))
								.addContainerGap())
							.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
								.addComponent(label)
								.addGap(46))))
			);
			gl_panel.setVerticalGroup(
				gl_panel.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_panel.createSequentialGroup()
						.addGap(26)
						.addComponent(label)
						.addPreferredGap(ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
						.addComponent(list, GroupLayout.PREFERRED_SIZE, 190, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
							.addComponent(btnOpen)
							.addComponent(btnSave))
						.addGap(13))
			);
			panel.setLayout(gl_panel);
			outPutThread.start();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public JTextArea getTxtMessages() {
		return this.txtMessages;
	}
	
	
	
	public void initComponents() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelMessage = new JPanel();
		panelMessage.setBackground(new Color(240, 248, 255));
		panelMessage.setBorder(new TitledBorder(null, "Message", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelMessage.setToolTipText("");
		add(panelMessage, BorderLayout.SOUTH);
		
		JScrollPane jScrollPane = new JScrollPane();
		
		txtMessage = new JTextArea();
		jScrollPane.setViewportView(txtMessage);
		
		JButton btnSend = new JButton("Send");
		btnSend.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				btnSendActionPerformed(e);
			}
		});
		
		JButton btnFile = new JButton("File");
		btnFile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				evtFile(arg0);
				
			}
		});
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Img", "File"}));
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
						System.exit(0);
				
			}
		});
		GroupLayout gl_panelMessage = new GroupLayout(panelMessage);
		gl_panelMessage.setHorizontalGroup(
			gl_panelMessage.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelMessage.createSequentialGroup()
					.addComponent(jScrollPane, GroupLayout.PREFERRED_SIZE, 354, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnSend)
					.addGap(45)
					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnFile)
					.addPreferredGap(ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
					.addComponent(btnExit, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
					.addGap(29))
		);
		gl_panelMessage.setVerticalGroup(
			gl_panelMessage.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelMessage.createSequentialGroup()
					.addGap(32)
					.addGroup(gl_panelMessage.createParallelGroup(Alignment.BASELINE)
						.addComponent(jScrollPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnExit)
						.addComponent(btnSend)
						.addComponent(btnFile)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		panelMessage.setLayout(gl_panelMessage);
		
		JScrollPane jScrollPane2 = new JScrollPane();
		add(jScrollPane2, BorderLayout.CENTER);
		
		txtMessages = new JTextArea();
		txtMessages.setBackground(new Color(192, 192, 192));
		jScrollPane2.setViewportView(txtMessages);
	}
	private void evtFile (java.awt.event.ActionEvent evt) {
		JFileChooser ch = new JFileChooser();
		int c = ch.showOpenDialog(this);
		if(c == JFileChooser.APPROVE_OPTION) {
			try {
				File f =  ch.getSelectedFile();
				FileInputStream in;			
				in = new FileInputStream(f);
				byte b[]= new byte[in.available()];
				in.read(b);
				Data2 data = new Data2();
				data.setFile(b);
				data.setName(f.getName());
				if (comboBox.getSelectedItem().toString().equals("Img")) {
					data.setStt("Img");
				}
				else {
					data.setStt("File");
				}
				data.setName(f.getName());
				out.writeObject(data);
				out.flush();
				this.txtMessages.append("\nDa Gui 1  file...");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}
	private void btnSendActionPerformed(ActionEvent e) {
		if(this.txtMessage.getText().trim().length() == 0) return;
		try {
			Data2 data = new Data2();
			data.setMess(txtMessage.getText());
			data.setStt("mess");
			out.writeObject(data);
			out.flush();
			this.txtMessages.append(String.format("\n%s: %s", this.sender, this.txtMessage.getText()));
			this.txtMessage.setText("");
		} catch (Exception except) {
			except.printStackTrace();
		}
	}
}
