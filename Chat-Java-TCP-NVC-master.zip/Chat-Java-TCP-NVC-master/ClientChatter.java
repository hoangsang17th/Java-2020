package CuoiKy;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.border.TitledBorder;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class ClientChatter extends JFrame {


	private JPanel contentPane;
	private JTextField txtStaff;
	private JTextField txtServerIP;
	private JTextField txtServerPort;
	Socket mngSocket = null;
	String mngIP = "";
	int mngPort = 0;
	String staffName = "";
	ObjectOutputStream out;
	OutputThread outputThread = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientChatter frame = new ClientChatter();
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClientChatter() {
		setTitle("Client");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 200, 858, 553);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel jPanel1 = new JPanel();
		jPanel1.setBorder(new TitledBorder(null, "Staff and Server Info", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(jPanel1, BorderLayout.NORTH);
		jPanel1.setLayout(new GridLayout(1, 7, 0, 0));
		
		JLabel lblStaff = new JLabel("Staff:");
		lblStaff.setHorizontalAlignment(SwingConstants.TRAILING);
		jPanel1.add(lblStaff);
		
		txtStaff = new JTextField();
		jPanel1.add(txtStaff);
		txtStaff.setColumns(10);
		
		JLabel lblManagerIp = new JLabel("Manager IP:");
		lblManagerIp.setHorizontalAlignment(SwingConstants.TRAILING);
		jPanel1.add(lblManagerIp);
		
		txtServerIP = new JTextField();
		txtServerIP.setText("localhost");
		jPanel1.add(txtServerIP);
		txtServerIP.setColumns(10);
		
		JLabel lblPort = new JLabel("Port:");
		lblPort.setHorizontalAlignment(SwingConstants.TRAILING);
		jPanel1.add(lblPort);
		
		txtServerPort = new JTextField();
		txtServerPort.setText("2211");
		jPanel1.add(txtServerPort);
		txtServerPort.setColumns(10);
		
		JButton btnConnect = new JButton("Connect");
		btnConnect.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				btnConnectActionPerformed(arg0);
				
			}
		});
		jPanel1.add(btnConnect);
	}
	
	private void btnConnectActionPerformed (ActionEvent e) {
		mngIP = this.txtServerIP.getText();
		mngPort = Integer.parseInt(this.txtServerPort.getText());
		staffName = this.txtStaff.getText();
		try {
			mngSocket = new Socket(mngIP, mngPort);
			if(mngSocket != null) {
				ChatPanel chatPanel = new ChatPanel(mngSocket, staffName, "Manager");
				this.getContentPane().add(chatPanel);
				chatPanel.getTxtMessages().append("Manager is running...");
				chatPanel.updateUI();
				out = new ObjectOutputStream(mngSocket.getOutputStream());
				Data2 data = new Data2();
				data.setName(staffName);
				out.writeObject(data);
				out.flush();
				
				System.out.println(String.format("Staff: %s", staffName));
				
			}
		} catch (Exception e2) {
			JOptionPane.showMessageDialog(this, "Manager is not running.");
			System.exit(0);
		}
	}

}
